package com.rokid.skill.constants;

public final class URI {
	// 健康检查
	public static final String HEALTH_CHECK = "/healthCheck";
	// 设备调用统一入口
	public static final String SPEECHLET = "/speechlet";
}
