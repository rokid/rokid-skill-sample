package com.rokid.skill.constants;

/**
 * 数据响应的内容
 * 
 * @author Bassam
 *
 */
public interface ResponseProduces {
	public static final String APP_JSON = "application/json;charset=UTF-8";
}
